# Попытка 1: дообучить BERT на тренировочном датасете. Я добавила два линейных слоя, не обновляя предобученные веса.
## Не очень хорошо работало с моими гиперпараметрами, попробовать эту идею еще раз не хватило ресурсов.

# Попытка 2: использовать Doc2Vec для эмбеддингов и обучить сеть с LSTM слоем.
## Работало хуже, чем та же модель с bag-of-words.

# Финальное решение: использовать bag-of words и сеть с архитектурой
## Linear -> LSTM -> Dropout(0.5) -> Linear -> Linear
## batch_size = 512, epochs = 10 (дальше все переобучается)


# Импорт библиотек
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import classification_report
import pymorphy2
import nltk
nltk.download('punkt')
nltk.download('stopwords')
from nltk.corpus import stopwords
stopwords = stopwords.words("english")
from nltk.tokenize import word_tokenize
import re
from keras.models import Sequential
from keras.layers import Dense, Reshape, LSTM, Dropout
from keras import metrics


# Загрузка данных
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')

# Лемматизация
morph = pymorphy2.MorphAnalyzer()

## train
data = []
for i in range(len(train)):
    s = str(train['title'][i])
    s = re.sub(r"[,.?:“/!@#$—ツ►๑۩۞۩•*”˜˜”*°°*'`)(0-9]", '', s)

    tokens = word_tokenize(s.lower())
    doc_stem = []
    for j in range(len(tokens)):
        tokens[j] = morph.parse(tokens[j])[0].normal_form
        if tokens[j] not in stopwords:
          doc_stem.append(tokens[j])
    data.append(' '.join(doc_stem))


## test
test_data = []
for i in range(len(test)):
    s = str(test['title'][i])
    s = re.sub(r"[,.?:“/!@#$—ツ►๑۩۞۩•*”˜˜”*°°*`')(0-9]", '', s)

    tokens = word_tokenize(s.lower())
    doc_stem = []
    for j in range(len(tokens)):
        tokens[j] = morph.parse(tokens[j])[0].normal_form
        if tokens[j] not in stopwords:
          doc_stem.append(tokens[j])
    test_data.append(' '.join(doc_stem))


# train, val, test
## Для поиска модели проводилось разделение. Для итоговой модели использовались все данные.
X = np.array(data)
y = np.array(train['lib'])
labels = np.unique(y)
y_num = np.copy(y)
for i in range(len(labels)):
    y_num = np.where(y == labels[i], i, y_num)
y_num = y_num.astype(int)
### X_train, X_test, y_train, y_test = train_test_split(X,y_num, test_size = 0.3, random_state = 2)
### X_val, X_test, y_val, y_test = train_test_split(X_test, y_test, test_size = 0.5, random_state = 2)



# Vectorizer: tf-idf работал хуже, чем просто count
vectorizer = CountVectorizer(ngram_range=(1, 1))
X_train = vectorizer.fit_transform(X)
X_test  = vectorizer.transform(test_data)

y_train = np.array(pd.get_dummies(y_num))



# Модель
model = Sequential()
model.add(Dense(128, activation='relu'))
model.add(Reshape((1, 128)))
model.add(LSTM(64))
model.add(Dropout(0.5))
model.add(Dense(256, activation='relu'))
model.add(Dense(24, activation='softmax'))
model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy', metrics.Precision()])
np.random.seed(2)
model.fit(X_train.toarray(), y_train, epochs=10, batch_size=512)

# Предсказания
pred = model.predict(X_test)
pred = np.argmax(pred, axis = 1)
pred_lab = np.copy(pred).astype(str)
for i in range(len(labels)):
    pred_lab = np.where(pred_lab == str(i), labels[i], pred_lab)
test['lib'] = pred_lab
sub = test[['id', 'lib']]
sub.to_csv('./submission.csv')